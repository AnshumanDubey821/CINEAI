// src/pages/LoginPage.jsx
import React, { useState, useEffect, useRef } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import './LoginPage.css';

/* ─── Floating movie title data for the background ─────────────────── */
const MOVIE_TITLES = [
  'Inception', 'Interstellar', 'The Dark Knight', 'Pulp Fiction',
  'The Godfather', 'Parasite', 'Fight Club', 'Goodfellas',
  'The Matrix', 'Spirited Away', 'Forrest Gump', 'Schindler\'s List',
  'La La Land', 'Whiplash', 'Get Out', 'Mad Max: Fury Road',
  'Her', 'Arrival', 'Blade Runner', 'Oldboy', 'Amélie',
  'Moonlight', 'Portrait of a Lady', 'Everything Everywhere',
  '2001: A Space Odyssey', 'Citizen Kane', 'Vertigo', 'Psycho',
  'No Country for Old Men', 'There Will Be Blood',
];

/* Each "film strip" column gets a random subset of titles */
function buildStrip(count = 12) {
  const shuffled = [...MOVIE_TITLES].sort(() => Math.random() - 0.5);
  return Array.from({ length: count }, (_, i) => shuffled[i % shuffled.length]);
}

/* ─── Film strip column component ────────────────────────────────── */
function FilmStrip({ titles, direction = 'up', duration = 30, opacity = 0.06 }) {
  return (
    <div
      className="film-strip"
      style={{
        '--dur': `${duration}s`,
        '--dir': direction === 'up' ? '-50%' : '0%',
        '--dir-end': direction === 'up' ? '0%' : '-50%',
        opacity,
      }}
    >
      {/* Duplicate list so it scrolls infinitely */}
      {[...titles, ...titles].map((t, i) => (
        <div key={i} className="film-strip__cell">
          <span className="film-strip__frame">▶</span>
          <span className="film-strip__title">{t}</span>
        </div>
      ))}
    </div>
  );
}

/* ─── Main component ─────────────────────────────────────────────── */
export default function LoginPage() {
  const { login, user }         = useAuth();
  const navigate                = useNavigate();
  const location                = useLocation();
  const from                    = location.state?.from?.pathname || '/';

  // Redirect if already logged in
  useEffect(() => { if (user) navigate(from, { replace: true }); }, [user]);

  /* tab: 'login' | 'signup' */
  const [tab, setTab]           = useState('login');
  const [email, setEmail]       = useState('');
  const [password, setPassword] = useState('');
  const [name, setName]         = useState('');
  const [showPass, setShowPass] = useState(false);
  const [loading, setLoading]   = useState(false);
  const [googleLoading, setGL]  = useState(false);
  const [error, setError]       = useState('');
  const [success, setSuccess]   = useState('');
  const googleBtnRef            = useRef(null);

  /* ── Google One Tap / Sign-In button ───────────────────────────── */
  useEffect(() => {
    // Load the Google Identity Services script
    const scriptId = 'google-gsi-script';
    if (!document.getElementById(scriptId)) {
      const script    = document.createElement('script');
      script.id       = scriptId;
      script.src      = 'https://accounts.google.com/gsi/client';
      script.async    = true;
      script.defer    = true;
      script.onload   = initGoogle;
      document.head.appendChild(script);
    } else {
      // Script already loaded (e.g. hot-reload)
      if (window.google?.accounts?.id) initGoogle();
      else document.getElementById(scriptId).addEventListener('load', initGoogle);
    }

    function initGoogle() {
      if (!window.google?.accounts?.id) return;

      // ── REPLACE the string below with your real Google Client ID ──
      // Get one free at: https://console.cloud.google.com/
      //   1. Create project → APIs & Services → Credentials
      //   2. Create OAuth 2.0 Client ID (Web application)
      //   3. Add http://localhost:3000 to Authorised JS origins
      const CLIENT_ID = 'YOUR_GOOGLE_CLIENT_ID.apps.googleusercontent.com';

      window.google.accounts.id.initialize({
        client_id: CLIENT_ID,
        callback: handleGoogleCredential,
        auto_select: false,
        cancel_on_tap_outside: true,
      });

      // Render the styled Google button inside our custom wrapper
      if (googleBtnRef.current) {
        window.google.accounts.id.renderButton(googleBtnRef.current, {
          theme: 'filled_black',
          size: 'large',
          shape: 'rectangular',
          width: 380,
          text: 'continue_with',
          logo_alignment: 'left',
        });
      }
    }
  }, []);

  /* Called by Google after user picks their account */
  function handleGoogleCredential(response) {
    setGL(true);
    setError('');
    try {
      // Decode the JWT payload (not verified client-side — send to backend in production)
      const payload = JSON.parse(atob(response.credential.split('.')[1]));
      const userData = {
        id:       payload.sub,
        name:     payload.name,
        email:    payload.email,
        avatar:   payload.picture,
        provider: 'google',
      };
      login(userData);
      setSuccess(`Welcome, ${payload.name}! 🎬`);
      setTimeout(() => navigate(from, { replace: true }), 900);
    } catch (e) {
      setError('Google sign-in failed. Please try again.');
    } finally {
      setGL(false);
    }
  }

  /* ── Email / Password submit ─────────────────────────────────── */
  async function handleEmailSubmit(e) {
    e.preventDefault();
    setError('');
    if (!email || !password) { setError('Please fill in all fields.'); return; }
    if (password.length < 6) { setError('Password must be at least 6 characters.'); return; }

    setLoading(true);
    // ── In production: replace this with a real API call ──────────
    // e.g. const res = await api.post('/auth/login', { email, password });
    await new Promise(r => setTimeout(r, 900));   // simulate network

    const userData = {
      id:       `email_${Date.now()}`,
      name:     name || email.split('@')[0],
      email,
      avatar:   null,
      provider: 'email',
    };
    login(userData);
    setSuccess(`Welcome back! 🎬`);
    setTimeout(() => navigate(from, { replace: true }), 800);
    setLoading(false);
  }

  /* ── Demo / Guest login ───────────────────────────────────────── */
  function handleDemo() {
    login({
      id: 'guest_001',
      name: 'Guest User',
      email: 'guest@cineai.app',
      avatar: null,
      provider: 'demo',
    });
    navigate(from, { replace: true });
  }

  /* ── Strips config ────────────────────────────────────────────── */
  const strips = [
    { titles: buildStrip(), direction: 'up',   duration: 35, opacity: 0.055 },
    { titles: buildStrip(), direction: 'down', duration: 28, opacity: 0.04  },
    { titles: buildStrip(), direction: 'up',   duration: 42, opacity: 0.06  },
    { titles: buildStrip(), direction: 'down', duration: 32, opacity: 0.045 },
    { titles: buildStrip(), direction: 'up',   duration: 38, opacity: 0.05  },
    { titles: buildStrip(), direction: 'down', duration: 25, opacity: 0.035 },
    { titles: buildStrip(), direction: 'up',   duration: 45, opacity: 0.065 },
    { titles: buildStrip(), direction: 'down', duration: 30, opacity: 0.04  },
  ];

  return (
    <div className="login-root">

      {/* ── Cinematic background ─────────────────────────────────── */}
      <div className="login-bg" aria-hidden="true">
        {/* Film-reel strips scrolling vertically */}
        <div className="login-bg__strips">
          {strips.map((s, i) => (
            <FilmStrip key={i} {...s} />
          ))}
        </div>

        {/* Dark vignette overlay */}
        <div className="login-bg__vignette" />

        {/* Cinematic colour leaks */}
        <div className="login-bg__leak login-bg__leak--gold" />
        <div className="login-bg__leak login-bg__leak--red"  />
        <div className="login-bg__leak login-bg__leak--blue" />

        {/* Horizontal scan lines */}
        <div className="login-bg__scanlines" />
      </div>

      {/* ── Card ──────────────────────────────────────────────────── */}
      <div className="login-card">

        {/* Logo */}
        <div className="login-logo">
          <span className="login-logo__icon">🎬</span>
          <span className="login-logo__text">Cine<em>AI</em></span>
        </div>

        <p className="login-tagline">Your personal AI film curator</p>

        {/* Tab switcher */}
        <div className="login-tabs">
          <button
            className={`login-tab ${tab === 'login' ? 'login-tab--active' : ''}`}
            onClick={() => { setTab('login'); setError(''); }}
          >Sign In</button>
          <button
            className={`login-tab ${tab === 'signup' ? 'login-tab--active' : ''}`}
            onClick={() => { setTab('signup'); setError(''); }}
          >Create Account</button>
        </div>

        {/* Success banner */}
        {success && (
          <div className="login-success">
            <span>✓</span> {success}
          </div>
        )}

        {/* Error banner */}
        {error && (
          <div className="login-error">
            <span>⚠</span> {error}
          </div>
        )}

        {/* ── Google button (rendered by GSI SDK) ───────────────── */}
        <div className="login-google-wrapper">
          {/* The SDK injects its button into this div */}
          <div ref={googleBtnRef} className="login-google-sdk-btn" />

          {/* Fallback styled button shown before SDK loads */}
          {!window.google?.accounts?.id && (
            <button
              className="login-google-fallback"
              onClick={() => setError('Add your Google Client ID in LoginPage.jsx to enable Google login.')}
              disabled={googleLoading}
            >
              <svg className="login-google-icon" viewBox="0 0 24 24">
                <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/>
                <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/>
                <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"/>
                <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"/>
              </svg>
              Continue with Google
            </button>
          )}
        </div>

        {/* Divider */}
        <div className="login-divider">
          <span>or continue with email</span>
        </div>

        {/* ── Email form ─────────────────────────────────────────── */}
        <form className="login-form" onSubmit={handleEmailSubmit} noValidate>
          {tab === 'signup' && (
            <div className="login-field">
              <label htmlFor="name">Full Name</label>
              <input
                id="name" type="text" placeholder="Anshuman Dubey"
                value={name} onChange={e => setName(e.target.value)}
                autoComplete="name"
              />
            </div>
          )}

          <div className="login-field">
            <label htmlFor="email">Email Address</label>
            <input
              id="email" type="email" placeholder="you@example.com"
              value={email} onChange={e => setEmail(e.target.value)}
              autoComplete="email"
            />
          </div>

          <div className="login-field">
            <label htmlFor="password">
              Password
              {tab === 'login' && (
                <button type="button" className="login-forgot">Forgot password?</button>
              )}
            </label>
            <div className="login-pass-wrap">
              <input
                id="password"
                type={showPass ? 'text' : 'password'}
                placeholder={tab === 'signup' ? 'Min. 6 characters' : '••••••••'}
                value={password} onChange={e => setPassword(e.target.value)}
                autoComplete={tab === 'signup' ? 'new-password' : 'current-password'}
              />
              <button
                type="button"
                className="login-pass-toggle"
                onClick={() => setShowPass(v => !v)}
                aria-label={showPass ? 'Hide password' : 'Show password'}
              >
                {showPass ? '🙈' : '👁️'}
              </button>
            </div>
          </div>

          <button
            className="login-submit"
            type="submit"
            disabled={loading}
          >
            {loading
              ? <span className="login-spinner" />
              : tab === 'login' ? 'Sign In →' : 'Create Account →'
            }
          </button>
        </form>

        {/* Guest / Demo */}
        <button className="login-demo" onClick={handleDemo}>
          Continue as Guest — no sign-in required
        </button>

        {/* Footer note */}
        <p className="login-terms">
          By continuing you agree to our{' '}
          <span className="login-link">Terms of Service</span> and{' '}
          <span className="login-link">Privacy Policy</span>
        </p>
      </div>

      {/* Floating decorative reel icons */}
      <div className="login-reel login-reel--tl" aria-hidden="true">🎞️</div>
      <div className="login-reel login-reel--br" aria-hidden="true">🎞️</div>
    </div>
  );
}
