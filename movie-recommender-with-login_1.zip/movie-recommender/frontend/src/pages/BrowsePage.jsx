// src/pages/BrowsePage.jsx
// Browse / search all movies with genre filtering and pagination.
import React, { useState, useEffect, useCallback } from 'react';
import { useSearchParams } from 'react-router-dom';
import { fetchAllMovies, searchMovies, fetchGenres } from '../utils/api';
import axios from 'axios';

const API_BASE = process.env.REACT_APP_API_URL || 'http://localhost:8000';
import MovieGrid from '../components/MovieGrid';
import SectionHeader from '../components/SectionHeader';
import './BrowsePage.css';

const GENRE_ICONS = {
  Action:'💥', Adventure:'🗺️', Animation:'🎨', Biography:'📖',
  Comedy:'😂', Crime:'🔍', Documentary:'📽️', Drama:'🎭',
  Fantasy:'🔮', History:'🏛️', Horror:'👻', Music:'🎵',
  Musical:'🎼', Mystery:'🕵️', Romance:'💕', 'Sci-Fi':'🚀',
  Sport:'🏆', Thriller:'😱', War:'⚔️', Western:'🤠',
};

export default function BrowsePage() {
  const [searchParams, setSearchParams] = useSearchParams();

  const [movies, setMovies]     = useState([]);
  const [genres, setGenres]     = useState([]);
  const [loading, setLoading]   = useState(true);
  const [query, setQuery]       = useState(searchParams.get('q') || '');
  const [activeGenre, setGenre] = useState(searchParams.get('genre') || '');
  const [page, setPage]         = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [totalCount, setTotalCount] = useState(0);

  const PER_PAGE = 48;

  // Load genres once
  useEffect(() => {
    fetchGenres().then(d => setGenres(d.genres || [])).catch(() => {});
  }, []);

  // Main data loader
  const load = useCallback(async (q, genre, pg) => {
    setLoading(true);
    try {
      if (q.trim()) {
        // Search mode
        const data = await searchMovies(q.trim(), 100);
        const all = data.movies || [];
        setTotalCount(all.length);
        setTotalPages(Math.ceil(all.length / PER_PAGE));
        setMovies(all.slice((pg - 1) * PER_PAGE, pg * PER_PAGE));
      } else if (genre) {
        // Genre filter mode — GET /recommend/by-genre?genre=X&n=200
        const data = await axios.get(`${API_BASE}/recommend/by-genre`, {
          params: { genre, n: 200 }
        }).then(r => r.data);
        const all = data.recommendations || [];
        setTotalCount(all.length);
        setTotalPages(Math.ceil(all.length / PER_PAGE));
        setMovies(all.slice((pg - 1) * PER_PAGE, pg * PER_PAGE));
      } else {
        // Default: all movies paginated
        const data = await fetchAllMovies(pg, PER_PAGE);
        setMovies(data.movies || []);
        setTotalPages(data.pages || 1);
        setTotalCount(data.total || 0);
      }
    } catch (err) {
      console.error(err);
      setMovies([]);
    } finally {
      setLoading(false);
    }
  }, []);

  // React to param changes
  useEffect(() => {
    const q = searchParams.get('q') || '';
    const g = searchParams.get('genre') || '';
    setQuery(q);
    setGenre(g);
    setPage(1);
    load(q, g, 1);
  }, [searchParams, load]);

  const handleSearch = (e) => {
    e.preventDefault();
    const params = {};
    if (query.trim()) params.q = query.trim();
    if (activeGenre) params.genre = activeGenre;
    setSearchParams(params);
  };

  const handleGenreClick = (g) => {
    const next = activeGenre === g ? '' : g;
    setGenre(next);
    const params = {};
    if (query.trim()) params.q = query.trim();
    if (next) params.genre = next;
    setSearchParams(params);
  };

  const handleClearFilters = () => {
    setQuery('');
    setGenre('');
    setSearchParams({});
  };

  const handlePageChange = (pg) => {
    setPage(pg);
    load(query, activeGenre, pg);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const hasFilters = query.trim() || activeGenre;

  const getTitle = () => {
    if (query.trim() && activeGenre) return `"${query}" · ${activeGenre}`;
    if (query.trim())  return `Search: "${query}"`;
    if (activeGenre)   return `${GENRE_ICONS[activeGenre] || '🎬'} ${activeGenre} Movies`;
    return 'All Movies';
  };

  return (
    <div className="browse-page">
      <div className="browse-page__container">

        {/* Page title */}
        <div className="browse-header fade-in">
          <h1 className="browse-header__title">Browse Movies</h1>
          <p className="browse-header__sub">
            Explore {totalCount > 0 ? totalCount.toLocaleString() : 'all'} movies — filter by genre or search by title.
          </p>
        </div>

        {/* Search bar */}
        <form className="browse-search" onSubmit={handleSearch}>
          <span className="browse-search__icon">🔍</span>
          <input
            className="browse-search__input"
            type="text"
            placeholder="Search by title…"
            value={query}
            onChange={e => setQuery(e.target.value)}
          />
          <button className="browse-search__btn" type="submit">Search</button>
        </form>

        {/* Genre pills */}
        <div className="browse-genres">
          {genres.map(g => (
            <button
              key={g}
              className={`browse-genre-pill ${activeGenre === g ? 'browse-genre-pill--active' : ''}`}
              onClick={() => handleGenreClick(g)}
            >
              {GENRE_ICONS[g] || '🎬'} {g}
            </button>
          ))}
        </div>

        {/* Active filter summary + clear */}
        {hasFilters && (
          <div className="browse-filter-bar fade-in">
            <span className="browse-filter-bar__label">Filtering by:</span>
            {query.trim() && <span className="browse-filter-tag">🔍 "{query}"</span>}
            {activeGenre && <span className="browse-filter-tag">{GENRE_ICONS[activeGenre] || '🎬'} {activeGenre}</span>}
            <button className="browse-filter-clear" onClick={handleClearFilters}>✕ Clear</button>
          </div>
        )}

        {/* Results */}
        <div className="browse-results">
          <SectionHeader
            title={getTitle()}
            subtitle={loading ? 'Loading…' : `${totalCount.toLocaleString()} movie${totalCount !== 1 ? 's' : ''}`}
          />
          <MovieGrid
            movies={movies}
            loading={loading}
            skeletonCount={PER_PAGE}
            emptyMessage="No movies match your search. Try different keywords or filters."
          />
        </div>

        {/* Pagination */}
        {!loading && totalPages > 1 && (
          <div className="browse-pagination">
            <button
              className="browse-page-btn"
              disabled={page <= 1}
              onClick={() => handlePageChange(page - 1)}
            >← Prev</button>

            {Array.from({ length: Math.min(totalPages, 7) }, (_, i) => {
              // Show pages around current
              let pg;
              if (totalPages <= 7) pg = i + 1;
              else if (page <= 4) pg = i + 1;
              else if (page >= totalPages - 3) pg = totalPages - 6 + i;
              else pg = page - 3 + i;
              return (
                <button
                  key={pg}
                  className={`browse-page-btn browse-page-btn--num ${page === pg ? 'browse-page-btn--active' : ''}`}
                  onClick={() => handlePageChange(pg)}
                >
                  {pg}
                </button>
              );
            })}

            <button
              className="browse-page-btn"
              disabled={page >= totalPages}
              onClick={() => handlePageChange(page + 1)}
            >Next →</button>
          </div>
        )}

      </div>
    </div>
  );
}
