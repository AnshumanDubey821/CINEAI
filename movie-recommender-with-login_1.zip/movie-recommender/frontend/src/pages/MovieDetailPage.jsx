// src/pages/MovieDetailPage.jsx
import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { fetchMovieById, fetchSimilar } from '../utils/api';
import MovieGrid from '../components/MovieGrid';
import SectionHeader from '../components/SectionHeader';
import './MovieDetailPage.css';

const GRADIENTS = [
  'linear-gradient(135deg, #1a1a2e 0%, #16213e 50%, #0f3460 100%)',
  'linear-gradient(135deg, #2d1b69 0%, #11998e 100%)',
  'linear-gradient(135deg, #3a0000 0%, #7b0000 50%, #c20000 100%)',
  'linear-gradient(135deg, #0f2027 0%, #203a43 50%, #2c5364 100%)',
  'linear-gradient(135deg, #232526 0%, #414345 100%)',
  'linear-gradient(135deg, #1f1c2c 0%, #928dab 100%)',
  'linear-gradient(135deg, #373b44 0%, #4286f4 100%)',
  'linear-gradient(135deg, #0d0d0d 0%, #2d2d2d 50%, #4a1942 100%)',
];
function getGrad(id) { return GRADIENTS[id % GRADIENTS.length]; }

function genreIcon(genres = '') {
  if (genres.includes('Animation')) return '🎨';
  if (genres.includes('Horror'))    return '👻';
  if (genres.includes('Comedy'))    return '😂';
  if (genres.includes('Romance'))   return '💕';
  if (genres.includes('Sci-Fi'))    return '🚀';
  if (genres.includes('War'))       return '⚔️';
  if (genres.includes('Western'))   return '🤠';
  if (genres.includes('Musical'))   return '🎵';
  if (genres.includes('Fantasy'))   return '🔮';
  if (genres.includes('Action'))    return '💥';
  if (genres.includes('Crime'))     return '🔍';
  if (genres.includes('Drama'))     return '🎭';
  return '🎬';
}

function RatingBar({ value, max = 5 }) {
  const pct = Math.min((value / max) * 100, 100);
  return (
    <div className="rating-bar">
      <div className="rating-bar__fill" style={{ width: `${pct}%` }} />
    </div>
  );
}

export default function MovieDetailPage() {
  const { id }                      = useParams();
  const [movie, setMovie]           = useState(null);
  const [similar, setSimilar]       = useState([]);
  const [activeTab, setActiveTab]   = useState('hybrid');
  const [loadingM, setLoadingM]     = useState(true);
  const [loadingS, setLoadingS]     = useState(true);
  const [error, setError]           = useState('');

  useEffect(() => {
    window.scrollTo(0, 0);
    const movieId = parseInt(id);
    setLoadingM(true);
    setLoadingS(true);
    setError('');

    fetchMovieById(movieId)
      .then(setMovie)
      .catch(() => setError('Movie not found.'))
      .finally(() => setLoadingM(false));

    fetchSimilar(movieId, 12, 'hybrid')
      .then(data => setSimilar(data.recommendations || []))
      .catch(() => {})
      .finally(() => setLoadingS(false));
  }, [id]);

  const handleTabChange = async (method) => {
    setActiveTab(method);
    setLoadingS(true);
    try {
      const data = await fetchSimilar(parseInt(id), 12, method);
      setSimilar(data.recommendations || []);
    } catch (_) {}
    finally { setLoadingS(false); }
  };

  if (loadingM) return (
    <div className="detail-loading">
      <div className="detail-loading__spinner" />
      <p>Loading movie…</p>
    </div>
  );

  if (error || !movie) return (
    <div className="detail-error">
      <h2>😕 {error || 'Something went wrong.'}</h2>
      <Link to="/" className="btn btn--primary">Go Home</Link>
    </div>
  );

  const genreList = (movie.genres || '').split('|');

  return (
    <div className="detail">
      {/* Backdrop */}
      <div
        className="detail__backdrop"
        style={{ background: getGrad(movie.movieId) }}
        aria-hidden="true"
      />

      <div className="detail__container">
        {/* Hero row */}
        <div className="detail__hero">
          {/* Poster */}
          <div
            className="detail__poster"
            style={{ background: getGrad(movie.movieId) }}
          >
            <span className="detail__poster-icon">{genreIcon(movie.genres)}</span>
          </div>

          {/* Meta */}
          <div className="detail__meta">
            <div className="detail__genres">
              {genreList.map(g => <span key={g} className="genre-pill">{g}</span>)}
            </div>

            <h1 className="detail__title">{movie.clean_title}</h1>

            {movie.year && <span className="detail__year">{movie.year}</span>}

            {/* Rating */}
            <div className="detail__rating">
              <div className="detail__stars">
                {[1,2,3,4,5].map(s => (
                  <span
                    key={s}
                    className={`detail__star ${s <= Math.round(movie.avg_rating) ? 'detail__star--on' : ''}`}
                  >★</span>
                ))}
              </div>
              <span className="detail__rating-val">{movie.avg_rating.toFixed(1)}</span>
              <span className="detail__rating-count">/ 5  ({movie.rating_count} ratings)</span>
              <RatingBar value={movie.avg_rating} />
            </div>

            {/* Stats */}
            <div className="detail__stats">
              <div className="detail__stat">
                <span className="detail__stat-label">Popularity</span>
                <span className="detail__stat-val">{(movie.popularity * 100).toFixed(1)}%</span>
              </div>
              <div className="detail__stat">
                <span className="detail__stat-label">Ratings</span>
                <span className="detail__stat-val">{movie.rating_count}</span>
              </div>
              <div className="detail__stat">
                <span className="detail__stat-label">Score</span>
                <span className="detail__stat-val">{movie.avg_rating.toFixed(2)}</span>
              </div>
            </div>

            <Link to="/recommend" className="btn btn--primary detail__rec-btn">
              🎬 Find Movies Like This
            </Link>
          </div>
        </div>

        {/* Similar movies */}
        <div className="detail__similar">
          <SectionHeader
            title="Similar Movies"
            subtitle="Powered by ML — choose your recommendation method"
          />

          {/* Method tabs */}
          <div className="detail__tabs">
            {[
              { key: 'hybrid',        label: '✨ Hybrid' },
              { key: 'content',       label: '📄 Content-Based' },
              { key: 'collaborative', label: '👥 Collaborative' },
            ].map(({ key, label }) => (
              <button
                key={key}
                className={`detail__tab ${activeTab === key ? 'detail__tab--active' : ''}`}
                onClick={() => handleTabChange(key)}
              >
                {label}
              </button>
            ))}
          </div>

          <MovieGrid movies={similar} loading={loadingS} skeletonCount={12} />
        </div>
      </div>
    </div>
  );
}
