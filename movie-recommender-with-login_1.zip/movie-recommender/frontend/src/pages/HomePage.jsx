// src/pages/HomePage.jsx
import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { fetchTrending, fetchGenres } from '../utils/api';
import MovieGrid from '../components/MovieGrid';
import SectionHeader from '../components/SectionHeader';
import './HomePage.css';

const GENRE_ICONS = {
  Action: '💥', Adventure: '🗺️', Animation: '🎨', Biography: '📖',
  Comedy: '😂', Crime: '🔍', Documentary: '📽️', Drama: '🎭',
  Fantasy: '🔮', History: '🏛️', Horror: '👻', Music: '🎵',
  Musical: '🎼', Mystery: '🕵️', Romance: '💕', 'Sci-Fi': '🚀',
  Sport: '🏆', Thriller: '😱', War: '⚔️', Western: '🤠',
};

export default function HomePage() {
  const [trending, setTrending]   = useState([]);
  const [genres, setGenres]       = useState([]);
  const [loading, setLoading]     = useState(true);
  const [heroQuery, setHeroQuery] = useState('');
  const navigate                  = useNavigate();

  useEffect(() => {
    const load = async () => {
      try {
        const [t, g] = await Promise.all([fetchTrending(20), fetchGenres()]);
        setTrending(t.movies || []);
        setGenres(g.genres || []);
      } catch (err) {
        console.error(err);
      } finally {
        setLoading(false);
      }
    };
    load();
  }, []);

  const handleHeroSearch = (e) => {
    e.preventDefault();
    if (heroQuery.trim()) navigate(`/browse?q=${encodeURIComponent(heroQuery.trim())}`);
  };

  return (
    <div className="home">
      {/* Hero */}
      <section className="hero">
        <div className="hero__bg" aria-hidden="true">
          {/* Decorative blurs */}
          <div className="hero__blob hero__blob--1" />
          <div className="hero__blob hero__blob--2" />
          <div className="hero__blob hero__blob--3" />
        </div>
        <div className="hero__content">
          <div className="hero__badge">✨ AI-Powered Recommendations</div>
          <h1 className="hero__title">
            Discover Your Next<br />
            <em>Favourite Film</em>
          </h1>
          <p className="hero__subtitle">
            Machine learning meets cinema. Get personalised picks using content-based
            &amp; collaborative filtering — find movies you'll love.
          </p>
          <form className="hero__search" onSubmit={handleHeroSearch}>
            <span className="hero__search-icon">🔍</span>
            <input
              className="hero__search-input"
              type="text"
              placeholder="Search a movie title…"
              value={heroQuery}
              onChange={e => setHeroQuery(e.target.value)}
              autoFocus
            />
            <button className="hero__search-btn" type="submit">Search</button>
          </form>
          <div className="hero__ctas">
            <Link to="/recommend" className="btn btn--primary">Get Recommendations →</Link>
            <Link to="/browse"    className="btn btn--ghost">Browse All Movies</Link>
          </div>
        </div>
      </section>

      {/* Trending */}
      <section className="section container">
        <SectionHeader
          title="🔥 Trending Now"
          subtitle="Top-rated films ranked by popularity score"
          action={<Link to="/browse" className="link-more">View all →</Link>}
        />
        <MovieGrid movies={trending} loading={loading} skeletonCount={10} />
      </section>

      {/* Genres */}
      {genres.length > 0 && (
        <section className="section container">
          <SectionHeader
            title="🎭 Browse by Genre"
            subtitle="Find movies that match your mood"
          />
          <div className="genre-grid">
            {genres.map(g => (
              <Link
                key={g}
                to={`/browse?genre=${encodeURIComponent(g)}`}
                className="genre-tile"
              >
                <span className="genre-tile__icon">{GENRE_ICONS[g] || '🎬'}</span>
                <span className="genre-tile__name">{g}</span>
              </Link>
            ))}
          </div>
        </section>
      )}

      {/* CTA Banner */}
      <section className="section container">
        <div className="cta-banner">
          <div className="cta-banner__text">
            <h2>Not sure what to watch?</h2>
            <p>Tell us a movie you loved and our AI will find similar ones instantly.</p>
          </div>
          <Link to="/recommend" className="btn btn--primary">Try the Recommender →</Link>
        </div>
      </section>
    </div>
  );
}
