// src/components/MovieCard.jsx
// Reusable card displayed in grids throughout the app.
import React from 'react';
import { Link } from 'react-router-dom';
import './MovieCard.css';

// Deterministic gradient per movieId so every card has a unique "poster"
const GRADIENTS = [
  'linear-gradient(135deg, #1a1a2e 0%, #16213e 50%, #0f3460 100%)',
  'linear-gradient(135deg, #2d1b69 0%, #11998e 100%)',
  'linear-gradient(135deg, #3a0000 0%, #7b0000 50%, #c20000 100%)',
  'linear-gradient(135deg, #0f2027 0%, #203a43 50%, #2c5364 100%)',
  'linear-gradient(135deg, #232526 0%, #414345 100%)',
  'linear-gradient(135deg, #1f1c2c 0%, #928dab 100%)',
  'linear-gradient(135deg, #373b44 0%, #4286f4 100%)',
  'linear-gradient(135deg, #0d0d0d 0%, #2d2d2d 50%, #4a1942 100%)',
  'linear-gradient(135deg, #200122 0%, #6f0000 100%)',
  'linear-gradient(135deg, #0a3d62 0%, #1e3799 100%)',
];

function getPosterGradient(movieId) {
  return GRADIENTS[movieId % GRADIENTS.length];
}

// Emoji icon representative of genre
function genreIcon(genres = '') {
  if (genres.includes('Animation'))  return '🎨';
  if (genres.includes('Horror'))     return '👻';
  if (genres.includes('Comedy'))     return '😂';
  if (genres.includes('Romance'))    return '💕';
  if (genres.includes('Sci-Fi'))     return '🚀';
  if (genres.includes('War'))        return '⚔️';
  if (genres.includes('Western'))    return '🤠';
  if (genres.includes('Musical'))    return '🎵';
  if (genres.includes('Fantasy'))    return '🔮';
  if (genres.includes('Action'))     return '💥';
  if (genres.includes('Crime'))      return '🔍';
  if (genres.includes('Drama'))      return '🎭';
  if (genres.includes('Biography'))  return '📖';
  return '🎬';
}

export default function MovieCard({ movie, size = 'default' }) {
  if (!movie) return null;

  const {
    movieId, clean_title, title, year, genres = '',
    avg_rating = 0, rating_count = 0,
  } = movie;

  const genreList = genres.split('|').slice(0, 3);

  return (
    <Link
      to={`/movie/${movieId}`}
      className={`movie-card movie-card--${size} fade-in`}
      aria-label={`View details for ${clean_title || title}`}
    >
      {/* Poster */}
      <div
        className="movie-card__poster"
        style={{ background: getPosterGradient(movieId) }}
      >
        <span className="movie-card__icon">{genreIcon(genres)}</span>
        {year && <span className="movie-card__year">{year}</span>}
      </div>

      {/* Info */}
      <div className="movie-card__info">
        <h3 className="movie-card__title">{clean_title || title}</h3>

        <div className="movie-card__genres">
          {genreList.map(g => (
            <span key={g} className="genre-pill">{g}</span>
          ))}
        </div>

        <div className="movie-card__footer">
          <span className="star-rating">
            <span className="star">★</span>
            {avg_rating.toFixed(1)}
            <span className="count">({rating_count})</span>
          </span>
        </div>
      </div>
    </Link>
  );
}
