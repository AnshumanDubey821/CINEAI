// src/components/Navbar.jsx
import React, { useState, useEffect, useRef } from 'react';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import { searchMovies } from '../utils/api';
import { useAuth } from '../context/AuthContext';
import './Navbar.css';

export default function Navbar() {
  const { user, logout }            = useAuth();
  const [query, setQuery]           = useState('');
  const [results, setResults]       = useState([]);
  const [searching, setSearching]   = useState(false);
  const [dropOpen, setDropOpen]     = useState(false);
  const [userMenuOpen, setUserMenu] = useState(false);
  const [scrolled, setScrolled]     = useState(false);
  const navigate                    = useNavigate();
  const location                    = useLocation();
  const dropRef                     = useRef(null);
  const userMenuRef                 = useRef(null);
  const timerRef                    = useRef(null);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 30);
    window.addEventListener('scroll', onScroll);
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  useEffect(() => {
    setDropOpen(false);
    setUserMenu(false);
    setQuery('');
    setResults([]);
  }, [location]);

  useEffect(() => {
    const handler = (e) => {
      if (dropRef.current && !dropRef.current.contains(e.target)) setDropOpen(false);
      if (userMenuRef.current && !userMenuRef.current.contains(e.target)) setUserMenu(false);
    };
    document.addEventListener('mousedown', handler);
    return () => document.removeEventListener('mousedown', handler);
  }, []);

  const handleInput = (e) => {
    const val = e.target.value;
    setQuery(val);
    clearTimeout(timerRef.current);
    if (val.trim().length < 2) { setResults([]); setDropOpen(false); return; }
    timerRef.current = setTimeout(async () => {
      setSearching(true);
      try {
        const data = await searchMovies(val.trim(), 8);
        setResults(data.movies || []);
        setDropOpen(true);
      } catch (_) {}
      finally { setSearching(false); }
    }, 350);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (query.trim()) {
      navigate(`/browse?q=${encodeURIComponent(query.trim())}`);
      setDropOpen(false);
    }
  };

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  // Avatar: first letter of name or Google picture
  const avatarLetter = user?.name?.charAt(0)?.toUpperCase() || '?';

  const navLinks = [
    { to: '/',         label: 'Home' },
    { to: '/browse',   label: 'Browse' },
    { to: '/recommend',label: 'Recommend' },
  ];

  return (
    <nav className={`navbar ${scrolled ? 'navbar--scrolled' : ''}`}>
      <div className="navbar__inner">
        {/* Logo */}
        <Link to="/" className="navbar__logo">
          <span className="navbar__logo-icon">🎬</span>
          <span className="navbar__logo-text">Cine<em>AI</em></span>
        </Link>

        {/* Nav links */}
        <ul className="navbar__links">
          {navLinks.map(({ to, label }) => (
            <li key={to}>
              <Link
                to={to}
                className={`navbar__link ${location.pathname === to ? 'navbar__link--active' : ''}`}
              >
                {label}
              </Link>
            </li>
          ))}
        </ul>

        {/* Search */}
        <div className="navbar__search" ref={dropRef}>
          <form onSubmit={handleSubmit} className="navbar__search-form">
            <span className="navbar__search-icon">🔍</span>
            <input
              className="navbar__search-input"
              type="text"
              placeholder="Search movies…"
              value={query}
              onChange={handleInput}
              autoComplete="off"
            />
            {searching && <span className="navbar__search-spinner" />}
          </form>

          {dropOpen && results.length > 0 && (
            <div className="navbar__dropdown">
              {results.map(movie => (
                <Link
                  key={movie.movieId}
                  to={`/movie/${movie.movieId}`}
                  className="navbar__dropdown-item"
                >
                  <div className="navbar__dropdown-title">{movie.clean_title}</div>
                  <div className="navbar__dropdown-meta">
                    {movie.year && <span>{movie.year}</span>}
                    <span>{movie.genres.split('|').slice(0,2).join(', ')}</span>
                    <span className="navbar__dropdown-rating">⭐ {movie.avg_rating}</span>
                  </div>
                </Link>
              ))}
              <button
                className="navbar__dropdown-more"
                onClick={() => { navigate(`/browse?q=${encodeURIComponent(query)}`); setDropOpen(false); }}
              >
                See all results for "{query}"
              </button>
            </div>
          )}
        </div>

        {/* User Avatar Menu */}
        {user && (
          <div className="navbar__user" ref={userMenuRef}>
            <button
              className="navbar__avatar"
              onClick={() => setUserMenu(v => !v)}
              aria-label="User menu"
            >
              {user.avatar
                ? <img src={user.avatar} alt={user.name} className="navbar__avatar-img" referrerPolicy="no-referrer" />
                : <span className="navbar__avatar-letter">{avatarLetter}</span>
              }
            </button>

            {userMenuOpen && (
              <div className="navbar__user-menu">
                <div className="navbar__user-info">
                  <div className="navbar__user-name">{user.name}</div>
                  <div className="navbar__user-email">{user.email}</div>
                  {user.provider === 'google' && (
                    <span className="navbar__user-badge">Google</span>
                  )}
                  {user.provider === 'demo' && (
                    <span className="navbar__user-badge navbar__user-badge--guest">Guest</span>
                  )}
                </div>
                <div className="navbar__user-divider" />
                <button className="navbar__user-logout" onClick={handleLogout}>
                  <span>↩</span> Sign Out
                </button>
              </div>
            )}
          </div>
        )}
      </div>
    </nav>
  );
}
