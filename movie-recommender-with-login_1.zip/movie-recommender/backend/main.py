"""
Movie Recommendation System — FastAPI Backend
=============================================
Start with:  uvicorn main:app --reload --port 8000
Docs at:     http://localhost:8000/docs
"""

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from contextlib import asynccontextmanager

from model.recommender import recommender
from routes.movies    import router as movies_router
from routes.recommend import router as recommend_router


# ── Lifespan: load ML model once at startup ───────────────────────────────────
@asynccontextmanager
async def lifespan(app: FastAPI):
    print("🎬 Loading movie recommendation engine…")
    recommender.load_data()
    print("✅ Engine ready!")
    yield
    print("👋 Shutting down.")


# ── App ───────────────────────────────────────────────────────────────────────
app = FastAPI(
    title="🎬 Movie Recommendation API",
    description=(
        "Content-based + Collaborative Filtering recommendation system "
        "built on the MovieLens dataset."
    ),
    version="1.0.0",
    lifespan=lifespan,
)

# Allow the React dev server (port 3000) to call this API
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:3000", "http://127.0.0.1:3000"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# ── Routers ───────────────────────────────────────────────────────────────────
app.include_router(movies_router)
app.include_router(recommend_router)


# ── Health / Root ─────────────────────────────────────────────────────────────
@app.get("/", tags=["Health"])
def root():
    return {
        "status": "ok",
        "message": "Movie Recommendation API is running 🎬",
        "docs": "/docs",
        "endpoints": ["/movies", "/movies/trending", "/movies/search", "/recommend/by-movie", "/recommend/by-genre"],
    }


@app.get("/health", tags=["Health"])
def health():
    return {
        "status": "healthy",
        "model_loaded": recommender._is_loaded,
        "movies_count": len(recommender.movies_df) if recommender.movies_df is not None else 0,
    }
